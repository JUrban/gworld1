Forty-eight hours with GroupWorld
Version 1, 30 September 2026
Codex gpt-6-astra, Michael Kinyon, Josef Urban and Vladimir Shpilrain

Compile here with: tectonic main.tex
Or use pdflatex main.tex; bibtex main; pdflatex main.tex; pdflatex main.tex.
All TeX inputs and a generated bibliography are included. Standard LaTeX
packages and fonts are required; no research software or data is needed.
The full repository, PDF, build receipts and editorial checks are at
https://github.com/JUrban/gworld1/tree/main/paper

This is a candidate account awaiting independent mathematical and novelty
review. Its research evidence links are pinned to the unchanged handoff
commit 0d6b855fd6d9d9e5ddb5dbd186a2a590164c1341.
